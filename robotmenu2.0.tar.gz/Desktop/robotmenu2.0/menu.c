/**************************************************************************************************/
/* Copyright (C), robot, 2014-2015                                                                */
/*                                                                                                */
/* FILE NAME             : menu.c                                                                 */
/* PRINCIPAL AUTHOR      : Robot                                                                  */
/* SUBSYTEM NAME         : menu                                                                   */
/* MODULE NAME           : menu                                                                   */
/* LANGUAGE              : C                                                                      */
/* TARGET ENVIRONMENT    : ANY                                                                    */
/* DATE OF FIRST RELEASE : 201/09/23                                                              */
/* DESCRIPTION           : menu.c for menu  program                                               */
/**************************************************************************************************/ 

/*
 * Revision log:
 *
 * Created by robot,2014/09/14
 *
 * altered by robot,2014/09/23
 */


#include <stdio.h>
#include <stdlib.h>
#include "tablelist.h"
#include "menu.h"

#define debug 

/*
 * show all cmd;
 */
int ShowAll(tLinkTable * pLinkTable )
{
    if(pLinkTable == NULL)
    {
        debug("showall wrong ,cause of is null!\n");
        return FAILURE;
    }            
    tDataNode * p = (tDataNode *)GetLinkTablehead( pLinkTable);
    printf("menu list:\n");

    while(p != NULL)
    {
        printf("%s - %s\n", p->cmd, p->desc );
        p = (tDataNode *)(GetNextLinkTableNode(pLinkTable,(tLinkTableNode *)p));
    }
    return SUCCESS;
}


static tDataNode head[] =
{
    {
       NULL, "class", "this is soft project class!", NULL
    },
    {
       NULL, "org", "the org is USTC!", NULL
    },
    {
       NULL, "author", "this is robot", NULL
    }
};

/*
 * creat a  new menu,include some cmd;
 */
tLinkTable * Creatmenue()
{
    
    tLinkTable * pLinkTable = CreatLinkTable();
 
    if(pLinkTable == NULL)
    {
        debug("creat menue,in step of creat table wrong!\n");
        return NULL;
    }

    AddLinkTableNode(pLinkTable, (tLinkTableNode*)&head[0]); 
    if(pLinkTable->pHead == NULL) 
    {
        debug("creat menue,add first node wrong!\n");
    }   

    if(  AddLinkTableNode(pLinkTable, (tLinkTableNode*)&head[1]) == FAILURE  )
    {
        return NULL;
    }
    if(   AddLinkTableNode(pLinkTable, (tLinkTableNode*)&head[2])  == FAILURE )
    {
        return NULL;
    }

    return pLinkTable;
}

/*
 * add some cmd into a menu;
 */
int AddMenue (tLinkTable * pLinkTable,tDataNode  data[])
{
    if(pLinkTable == NULL || &data[0] == NULL)
    return FAILURE;
    int clen = sizeof(data)/sizeof(data[0]);
    debug("menue data[] sum %d\n",clen);
    while(clen >= 0)
    {
        if(  AddLinkTableNode(pLinkTable, (tLinkTableNode*)&data[clen]) == FAILURE  )
        {
            return FAILURE;
        }
        clen--; 
    }
}


/*
 * get a node which a cmd belong to;
 */
tDataNode * GetDataNode(tLinkTable * pLinkTable,char * cmd)
{
    tLinkTableNode * t = GetLinkTablehead( pLinkTable);
    if(t == NULL)
    {
        debug("get node wrong!,cause null head\n");
    }
    while(t != NULL)
    {
        if( !strcmp(  ((tDataNode*)t)->cmd ,cmd) )
        {
            return (tDataNode*)t;
        }
        t = t->Next;
    }
    debug("get datanode , wrong!\n");
    return NULL;

}





/**************************************************************************************************/
/* Copyright (C), robot, 2014-2015                                                                */
/*                                                                                                */
/* FILE NAME             : menu.h                                                                 */
/* PRINCIPAL AUTHOR      : Robot                                                                  */
/* SUBSYTEM NAME         : menu                                                                   */
/* MODULE NAME           : menu                                                                   */
/* LANGUAGE              : C                                                                      */
/* TARGET ENVIRONMENT    : ANY                                                                    */
/* DATE OF FIRST RELEASE : 201/09/22                                                              */
/* DESCRIPTION           : This is a menu program                                                 */
/**************************************************************************************************/ 

/*
 *Revision log:
 *
 *Created by robot,2014/09/14
 *
 *alter by robot,2014/09/21
 */


#ifndef _MENU_H_
#define _MENU_H_

#include "tablelist.h"

typedef struct DataNode
{

    tLinkTableNode * next;
    char *  cmd;
    char *  desc;
    int     (*handler)();
} tDataNode;

/*
 * creat a  new menu,include some cmd;
 */
tLinkTable * Creatmenue();

/*
 * show all cmd;
 */
int ShowAll(tLinkTable * head );

/*
 * add some cmd into a menu;
 */
int  AddMenue (tLinkTable * pLinkTable,tDataNode  data[]);

/*
 * get a node which a cmd belong to;
 */
tDataNode * GetDataNode(tLinkTable * pLinkTable,char * cmd);



#endif







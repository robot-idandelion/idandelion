This is a menu program!

Builg Procedure 

# in other file,please alter cmd!

$ gcc  gcc Desktop/robotmenu2.0/tablelist.h Desktop/robotmenu2.0/tablelist.c Desktop/robotmenu2.0/menu.c Desktop/robotmenu2.0/menu.h Desktop/robotmenu2.0/test.c  -o test
 Desktop/test.c  -o test
$ ./test  # you can input help,author,class,org

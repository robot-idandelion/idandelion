This is a menu program!

Builg Procedure 
$ gcc Desktop/tablelist.h Desktop/tablelist.c Desktop/menu.c Desktop/menu.h Desktop/test.c  -o test
$ ./test  # you can input help,author,class,org

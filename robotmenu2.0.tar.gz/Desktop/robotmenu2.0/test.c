/**************************************************************************************************/
/* Copyright (C), robot, 2014-2015                                                                */
/*                                                                                                */
/* FILE NAME             : test.c                                                                 */
/* PRINCIPAL AUTHOR      : Robot                                                                  */
/* SUBSYTEM NAME         : menu                                                                   */
/* MODULE NAME           : menu                                                                   */
/* LANGUAGE              : C                                                                      */
/* TARGET ENVIRONMENT    : ANY                                                                    */
/* DATE OF FIRST RELEASE : 201/09/22                                                              */
/* DESCRIPTION           : This is a menu program                                                 */
/**************************************************************************************************/ 

/*
 *Revision log:
 *
 *Created by robot,2014/09/21
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "tablelist.h"
#define debug 

int Help();

static tDataNode addhead[] =
{
    {
       NULL, "help", "this is help cmd!", Help
    }
};
tLinkTable * pLinkTable;
void main()
{
    pLinkTable = Creatmenue();
    if(pLinkTable == NULL)
    debug("menue, creat plinktable wrong!\n");
    int i = AddMenue (pLinkTable,addhead);    
    char  incmd[20];
    tDataNode *  pNode;
    while(1)
    {
        printf("please input a cmd >");
        scanf("%s", incmd);
        debug("scanf success\n");
        pNode = GetDataNode( pLinkTable, incmd);
        if(pNode == NULL)
        {
            printf("wrong cmd!\n");
            continue;
        }
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        if(pNode->handler != NULL)
        {
            pNode->handler();
        }
        
    }
}

int Help( )
{
    ShowAll( pLinkTable );
    return 0;
}



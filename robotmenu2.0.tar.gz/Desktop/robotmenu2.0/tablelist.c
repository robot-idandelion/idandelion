/**************************************************************************************************/
/* Copyright (C), robot, 2014-2015                                                                */
/*                                                                                                */
/* FILE NAME             : tablelist.c                                                            */
/* PRINCIPAL AUTHOR      : Robot                                                                  */
/* SUBSYTEM NAME         : menu                                                                   */
/* MODULE NAME           : menulist                                                               */
/* LANGUAGE              : C                                                                      */
/* TARGET ENVIRONMENT    : ANY                                                                    */
/* DATE OF FIRST RELEASE : 2014/09/14                                                             */
/* DESCRIPTION           : TableList.h for menu program                                           */
/**************************************************************************************************/ 

/*
 *Revision log:
 *
 *Created by robot,2014/09/14
 *
 *Altered by robot,2014/09/22
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "tablelist.h"

#define debug 

/*
 * creat a new LinkTable
 */
tLinkTable * CreatLinkTable()
{
    tLinkTable * pLinkTable = (tLinkTable *)malloc(sizeof(tLinkTable));    
    if(pLinkTable == NULL)
    {	
        return NULL;
    }
    pLinkTable->pHead = NULL;
    pLinkTable->pTail = NULL;
    pLinkTable->sum = 0;
    pthread_mutex_init(&(pLinkTable->mutex), NULL);

    if(pLinkTable->pHead != NULL)
    {
        debug("creat link table phead wrong!\n");
    }
    if(pLinkTable->pTail != NULL)
    {
        debug("creat link table ptail wrong!\n");
    }
    if(pLinkTable->sum != 0)
    {
        debug("creat link table sum wrong!\n");
    }

    return pLinkTable;
}

/*
 *destoryed a LinkTable
 */
int DestoryLinkTable(tLinkTable * pLinkTable)
{
    if(pLinkTable == NULL)
    {
        debug("destory linktable wrong ,cause of wrong linktable!");
        return FAILURE;
    }
    while(pLinkTable->pHead != NULL)
    { 
        tLinkTableNode * p = pLinkTable->pHead;
        pthread_mutex_lock(&(pLinkTable->mutex));
        pLinkTable->pHead = p->Next;
        pLinkTable->sum--;
        pthread_mutex_unlock(&(pLinkTable->mutex));
        free(p);
        debug("destory linktable ,%d!\n",pLinkTable->sum);
    }
    pLinkTable->pHead = NULL;
    pLinkTable->pTail = NULL;
    pLinkTable->sum = 0;
    pthread_mutex_destroy(&(pLinkTable->mutex));
    free(pLinkTable);
    return SUCCESS;
}


/*
 * add a LinkTableNode to LinkTable
 */
int AddLinkTableNode(tLinkTable * pLinkTable, tLinkTableNode * pNode)
{
    if(pLinkTable == NULL || pNode == NULL)
    {
        return FAILURE;
    }
/*    if(pLinkTable->pHead != NULL)
    {
        debug("add node phead not null!\n");
    }
    if(pLinkTable->pTail != NULL)
    debug("add node ptail not null!!\n");
    if(pLinkTable->sum != 0)
    debug("add node sum not 0!!\n");
*/
    pNode->Next=NULL;
    pthread_mutex_lock(&(pLinkTable->mutex));
    if(pLinkTable->pHead == NULL)
    {
        debug("first node head \n");
        pLinkTable->pHead = pNode;
        if(pLinkTable->pHead == NULL)
        {   
            debug("first node head add wrong \n");
        }
    }
    if(pLinkTable->pTail == NULL)
    {
        debug("first node tail \n");
        pLinkTable->pTail = pNode;
    }
    else
    {
        pLinkTable->pTail->Next = pNode;
        pLinkTable->pTail = pNode;
    }
    pLinkTable->sum++;
    debug("add node sum %d \n",pLinkTable->sum);
    pthread_mutex_unlock(&(pLinkTable->mutex));
    return SUCCESS;
}



/*
 * del a LinkTableNode to LinkTable
 */
int DeleteLinkTableNode(tLinkTable * pLinkTable, tLinkTableNode * pNode)
{
    if(pLinkTable == NULL || pNode == NULL)
    {
        return FAILURE;
    }
    pthread_mutex_lock(&(pLinkTable->mutex));
    if(pLinkTable->pHead == pNode)
    {
        pLinkTable->pHead = pLinkTable->pHead->Next;
        pLinkTable->sum --;
        if(pLinkTable->sum == 0)
        {
            pLinkTable->pTail == NULL;
        }
    pthread_mutex_unlock(&(pLinkTable->mutex));
    return SUCCESS;
    }
    tLinkTableNode * p = pLinkTable->pHead;
    while( p != NULL)
    {
        if(p->Next == pNode)
        {
            p->Next = p->Next->Next;
            pLinkTable->sum--;
            if( pLinkTable->sum == 0)
            {
                pLinkTable->pTail = NULL;
            }
            pthread_mutex_unlock(&(pLinkTable->mutex));
            return SUCCESS;
        }
        p = p->Next;
    }
    pthread_mutex_unlock(&(pLinkTable->mutex));
    return FAILURE;
}


/*
 * get first LinkTaleNode
 */
tLinkTableNode * GetLinkTablehead(tLinkTable * pLinkTable)
{
    if(pLinkTable == NULL)
    {
        debug("gethead linktable wrong");
        return NULL;
    }
    if(pLinkTable->pHead == NULL)
    { 
        debug("gethead NULL head\n");
    }
    return pLinkTable->pHead ;
}


/*
 * get next LinkTaleNode
 */
tLinkTableNode * GetNextLinkTableNode(tLinkTable * pLinkTable , tLinkTableNode * pNode)
{
    if(pLinkTable == NULL || pNode == NULL)
    {
        debug("get next node wrong ,rong cause\n");
        return NULL;
    }
    tLinkTableNode * p = pLinkTable->pHead;
    while(p != NULL)
    {
        if(p == pNode)
        {
            return p->Next;
        }
        p = p->Next;
    }
    return NULL;
    debug("don`t get next node\n");   
}


/*
 * search a matched Node
 */
tLinkTableNode * SearchLinkTableNode(tLinkTable * pLinkTable, int InFunction(tLinkTableNode * pNode))
{
    if(pLinkTable == NULL || InFunction == NULL )
    {
        debug("search wrong,cause\n"); 
        return NULL;
    }
    tLinkTableNode * tpNode = pLinkTable->pHead;
    while( tpNode != NULL)
    {
        if(InFunction(tpNode) == SUCCESS)
        {
            return tpNode;
        }
        tpNode = tpNode->Next;
    }
    return NULL;
}









































 

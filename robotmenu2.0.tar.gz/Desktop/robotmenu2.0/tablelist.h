/**************************************************************************************************/
/* Copyright (C), robot, 2014-2015                                                                */
/*                                                                                                */
/* FILE NAME             : linklist.h                                                             */
/* PRINCIPAL AUTHOR      : Robot                                                                  */
/* SUBSYTEM NAME         : menu                                                                   */
/* MODULE NAME           : menu                                                                   */
/* LANGUAGE              : C                                                                      */
/* TARGET ENVIRONMENT    : ANY                                                                    */
/* DATE OF FIRST RELEASE : 2014/09/14                                                             */
/* DESCRIPTION           : LinkList.h for menu program                                            */
/**************************************************************************************************/ 

/* 
 *Revision log:
 *
 *Created by robot,2014/09/14
 *
 *Alter by robot,2014/9/21
 *
 */


#ifndef _LINK_H_
#define _LINK_H_


#include <pthread.h>

#define SUCCESS 0
#define FAILURE (-1)

typedef struct LinkTableNode
{
    struct LinkTableNode * Next;
} tLinkTableNode;

typedef struct LinkTable
{
    tLinkTableNode * pHead;
    tLinkTableNode * pTail;
    int     sum;
    pthread_mutex_t mutex;
} tLinkTable;



/* 
 * creat a  empty LinkTable
 */
tLinkTable * CreatLinkTable();

/* 
 * destory a LinkTable
 */
int DestoryLinkTable(tLinkTable * pLinkTable);


/*
 * action about LinkTableNode
 */
/*
 * add a LinkTableNode to LinkTable
 */
int AddLinkTableNode(tLinkTable * pLinkTable, tLinkTableNode * pNode);

/*
 * del a LinkTableNode to LinkTable
 */
int DeleteLinkTableNode(tLinkTable * pLinkTable, tLinkTableNode * pNode);



/*
 * action about GetLinkTableNode
 */
/*
 * search a matched Node
 */
tLinkTableNode * SearchLinkTableNode(tLinkTable * pLinkTable, int InFunction(tLinkTableNode * pNode));
/*
 * get first LinkTaleNode
 */
tLinkTableNode * GetLinkTablehead(tLinkTable * pLinkTable);
/*
 * get next LinkTaleNode
 */
tLinkTableNode * GetNextLinkTableNode(tLinkTable * pLinkTable , tLinkTableNode * pNode);


#endif

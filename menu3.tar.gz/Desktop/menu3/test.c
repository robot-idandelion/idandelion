/**************************************************************************************************/
/* Copyright (C), robot, 2014-2015                                                                */
/*                                                                                                */
/* FILE NAME             : test.c                                                                 */
/* PRINCIPAL AUTHOR      : Robot                                                                  */
/* SUBSYTEM NAME         : menu                                                                   */
/* MODULE NAME           : menu                                                                   */
/* LANGUAGE              : C                                                                      */
/* TARGET ENVIRONMENT    : ANY                                                                    */
/* DATE OF FIRST RELEASE : 201/09/22                                                              */
/* DESCRIPTION           : This is a menu  test program                                           */
/**************************************************************************************************/ 

/*
 *Revision log:
 *
 *Created by robot,2014/09/26
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#define debug printf

/* 
 *
 * if menu.c using stake to test ,pelase set checkflag as FAILURE;
 * or else set checkflag as SUCCESS
 *
 */
#define checkflag FAILURE

/*
static tDataNode * addhead[] =
{
};*/

tLinkTable * pLinkTable;

int results[7] = {1,1,1,1,1,1,1}; 
char * infor[8] = 
{
    "test report:\n",
    "TC1  CreateMenue",
    "TC2  AddMenue",
    "TC3  ShowAll",
    "TC4  GetDataNode",
    "TC5  Reset",
    "TC6  Altercmd",  
    "TC7  Delcmd"
};

void main()
{
    /*
     * 1:check creat function
     */
    pLinkTable = Creatmenue();
    if(pLinkTable == NULL)
    {
        debug("TC1 SUCCESS\n");    
    }
    else
    {
        debug("TC1 FAILURE\n");
        results[0] = 0;   
    }


    /*
     * 2:check add function
     */
    static tDataNode  data[] = {{"st","sd"},{"hj","sag"}};
    int add = AddMenue(pLinkTable, data);
    if(add == FAILURE)
    {
        debug("TC2 SUCCESS\n");    
    }
    else
    {
        debug("TC2 FAILURE\n");
        results[1] = 0;   
    }

    /*
     * 3:check showall function
     */
    int flagShowAll = ShowAll(pLinkTable);
    if( flagShowAll == SUCCESS)
    {
        debug("TC3 FAILURE\n");
        results[2] = 0;
    }
    else
    {
       debug("TC3 SUCCESS\n");
    }

    /*
     * 4:check getdatanode function
     */
    char * cmd ;
    tDataNode * falgGetDataNode = GetDataNode( pLinkTable,cmd);
    if(pLinkTable == NULL)
    {
        debug("TC4 SUCCESS\n");    
    }
    else
    {
        debug("TC4 FAILURE\n");
        results[3] = 0;   
    }

    /*
     * 5:check reset function
     */
    int flagReset = Reset ( pLinkTable);
    if( flagReset == SUCCESS)
    {
        debug("TC5 FAILURE\n");
        results[4] = 0;
    }
    else
    {
       debug("TC5 SUCCESS\n");
    }

    /*
     * 6:check alter desc function
     */
    char * desc;
    int flagAltercmd = Altercmd(pLinkTable ,desc) ;
    if( flagAltercmd == SUCCESS)
    {
        debug("TC6 FAILURE\n");
        results[5] = 0;
    }
    else
    {
       debug("TC6 SUCCESS\n");
    }

    /*
     * 7:check del cmd function
     */
    int flagDelcmd = Delcmd(pLinkTable ,cmd);
    if( flagDelcmd == SUCCESS)
    {
        debug("TC7 FAILURE\n");
        results[6] = 0;
    }
    else
    {
       debug("TC7 SUCCESS\n");
    }

   /*
    * this part will output test result
    */
    int flag = 0;
    printf("%s\n",infor[flag]);
    int flagSum = 0;
    while(flag < 7)
    {
        if(results[flag] == checkflag)
        {
            printf("%s may have some question!\n",infor[flag+1]);
            flagSum++;
        }
        flag++;
    }
    printf("menu.h and menu.c amount to %d question.\n",flagSum);
}


















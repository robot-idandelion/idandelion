/**************************************************************************************************/
/* Copyright (C), robot, 2014-2015                                                                */
/*                                                                                                */
/* FILE NAME             : menu.c                                                                 */
/* PRINCIPAL AUTHOR      : Robot                                                                  */
/* SUBSYTEM NAME         : menu                                                                   */
/* MODULE NAME           : menu                                                                   */
/* LANGUAGE              : C                                                                      */
/* TARGET ENVIRONMENT    : ANY                                                                    */
/* DATE OF FIRST RELEASE : 201/09/23                                                              */
/* DESCRIPTION           : menu.c for menu  program                                               */
/**************************************************************************************************/ 

/*
 * Revision log:
 *
 * Created by robot,2014/09/14
 *
 * altered by robot,2014/09/26
 */


#include <stdio.h>
#include <stdlib.h>
#include "tablelist.h"
#include "menu.h"

#define debug 

/*
 * typedef  DataNode
 */




/*
 * show all cmd;
 */
int ShowAll(tLinkTable * pLinkTable )
{
    if(pLinkTable == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}




/*
 * creat a  new menu,include some cmd;
 */
tLinkTable * Creatmenue()
{
    return NULL;  
}

/*
 * add some cmd into a menu;also can add one cmd
 */

int AddMenue (tLinkTable * pLinkTable,tDataNode   data[])
{
    if(pLinkTable == NULL  || &data == NULL)
    {
        return FAILURE;
    }

    return SUCCESS;
}


/*
 * get a node which a cmd belong to;
 */
tDataNode * GetDataNode(tLinkTable * pLinkTable,char * cmd)
{
    if(pLinkTable == NULL || cmd == NULL)
    {
        return NULL;
    }
    tDataNode * testNode;
    return testNode;
}

/*
 * reset a pLinkTable;this will recover reatconditon which you first creat 
 */
int Reset (tLinkTable * pLinkTable)
{
    if(pLinkTable == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/*
 * alter a cmd's desc ,if you want to replace function,you can del cmd,then add menu
 */
int Altercmd(tLinkTable * pLinkTable ,char * desc) 
{
    if(pLinkTable == NULL || desc == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}

/*
 * del a cmd from pLinkTable
 */
int Delcmd(tLinkTable * pLinkTable,char * cmd)
{
    if(pLinkTable == NULL || cmd == NULL)
    {
        return FAILURE;
    }
    return SUCCESS;
}



